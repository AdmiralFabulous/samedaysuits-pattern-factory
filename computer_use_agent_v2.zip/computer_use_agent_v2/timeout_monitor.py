"""
Timeout Monitor - Detects and handles stalled agent runs.

Features:
- Background thread monitors for activity
- Configurable timeout thresholds
- Screenshot-based activity detection
- Graceful timeout handling with state preservation
"""

import os
import time
import threading
import signal
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Callable
import json


class TimeoutMonitor:
    """
    Monitors agent execution for timeouts and stalls.
    
    Detection methods:
    1. No new screenshots for N seconds
    2. No iteration progress for N seconds
    3. Total run time exceeds maximum
    4. Same screenshot hash for N consecutive captures (UI frozen)
    
    Usage:
        monitor = TimeoutMonitor(
            on_timeout=lambda reason: logger.timeout_run(reason),
            screenshot_timeout=120,  # 2 minutes no screenshot
            iteration_timeout=180,   # 3 minutes no iteration progress
            max_runtime=1800         # 30 minutes total
        )
        monitor.start()
        
        # During execution
        monitor.record_screenshot(hash_value)
        monitor.record_iteration(iteration_num)
        
        # On completion
        monitor.stop()
    """
    
    def __init__(
        self,
        on_timeout: Callable[[str], None],
        screenshot_timeout: int = 120,      # seconds
        iteration_timeout: int = 180,       # seconds
        max_runtime: int = 1800,            # seconds (30 min)
        frozen_ui_threshold: int = 5,       # consecutive identical screenshots
        check_interval: int = 10            # seconds between checks
    ):
        self.on_timeout = on_timeout
        self.screenshot_timeout = screenshot_timeout
        self.iteration_timeout = iteration_timeout
        self.max_runtime = max_runtime
        self.frozen_ui_threshold = frozen_ui_threshold
        self.check_interval = check_interval
        
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        
        # Tracking state
        self._start_time: Optional[float] = None
        self._last_screenshot_time: Optional[float] = None
        self._last_iteration_time: Optional[float] = None
        self._last_iteration: int = 0
        self._screenshot_hashes: list = []
        self._timed_out = False
    
    def start(self):
        """Start the timeout monitor thread."""
        if self._running:
            return
        
        self._running = True
        self._start_time = time.time()
        self._last_screenshot_time = time.time()
        self._last_iteration_time = time.time()
        self._timed_out = False
        self._screenshot_hashes = []
        
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()
    
    def stop(self):
        """Stop the timeout monitor."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None
    
    def record_screenshot(self, screenshot_hash: Optional[str] = None):
        """Record that a screenshot was captured."""
        with self._lock:
            self._last_screenshot_time = time.time()
            
            if screenshot_hash:
                self._screenshot_hashes.append(screenshot_hash)
                # Keep only last N hashes
                if len(self._screenshot_hashes) > self.frozen_ui_threshold + 1:
                    self._screenshot_hashes = self._screenshot_hashes[-self.frozen_ui_threshold - 1:]
    
    def record_iteration(self, iteration: int):
        """Record iteration progress."""
        with self._lock:
            if iteration > self._last_iteration:
                self._last_iteration = iteration
                self._last_iteration_time = time.time()
    
    def _monitor_loop(self):
        """Background monitoring loop."""
        while self._running and not self._timed_out:
            time.sleep(self.check_interval)
            
            if not self._running:
                break
            
            timeout_reason = self._check_timeouts()
            if timeout_reason:
                self._timed_out = True
                self._running = False
                
                # Call timeout handler
                try:
                    self.on_timeout(timeout_reason)
                except Exception as e:
                    print(f"Error in timeout handler: {e}")
    
    def _check_timeouts(self) -> Optional[str]:
        """Check all timeout conditions. Returns reason if timed out."""
        now = time.time()
        
        with self._lock:
            # Check max runtime
            if self._start_time and (now - self._start_time) > self.max_runtime:
                return f"Maximum runtime exceeded ({self.max_runtime}s)"
            
            # Check screenshot timeout
            if self._last_screenshot_time:
                screenshot_gap = now - self._last_screenshot_time
                if screenshot_gap > self.screenshot_timeout:
                    return f"No screenshot captured for {screenshot_gap:.0f}s (threshold: {self.screenshot_timeout}s)"
            
            # Check iteration timeout
            if self._last_iteration_time:
                iteration_gap = now - self._last_iteration_time
                if iteration_gap > self.iteration_timeout:
                    return f"No iteration progress for {iteration_gap:.0f}s (threshold: {self.iteration_timeout}s)"
            
            # Check for frozen UI (consecutive identical screenshots)
            if len(self._screenshot_hashes) >= self.frozen_ui_threshold:
                last_n = self._screenshot_hashes[-self.frozen_ui_threshold:]
                if len(set(last_n)) == 1:  # All identical
                    return f"UI appears frozen ({self.frozen_ui_threshold} identical consecutive screenshots)"
        
        return None
    
    @property
    def is_running(self) -> bool:
        return self._running
    
    @property
    def timed_out(self) -> bool:
        return self._timed_out
    
    def get_stats(self) -> dict:
        """Get current monitoring stats."""
        now = time.time()
        with self._lock:
            return {
                'running': self._running,
                'timed_out': self._timed_out,
                'runtime_seconds': (now - self._start_time) if self._start_time else 0,
                'seconds_since_screenshot': (now - self._last_screenshot_time) if self._last_screenshot_time else 0,
                'seconds_since_iteration': (now - self._last_iteration_time) if self._last_iteration_time else 0,
                'last_iteration': self._last_iteration,
                'screenshot_count': len(self._screenshot_hashes)
            }


class ActivityWatcher:
    """
    Watches run_logs directory for activity from external processes.
    Useful for monitoring runs started in background.
    
    Usage:
        watcher = ActivityWatcher("./run_logs/20260130_175916_export_pds_Basic_Tee")
        while watcher.is_active():
            status = watcher.get_status()
            print(f"Iteration: {status['current_iteration']}")
            time.sleep(5)
    """
    
    def __init__(self, run_dir: str):
        self.run_dir = Path(run_dir)
        self.metadata_file = self.run_dir / "metadata.json"
        self.pid_file = self.run_dir / "process.pid"
        self.screenshots_dir = self.run_dir / "screenshots"
        
        self._last_metadata_mtime: Optional[float] = None
        self._last_screenshot_count: int = 0
    
    def is_active(self) -> bool:
        """Check if the run is still active."""
        # Check if PID file exists
        if not self.pid_file.exists():
            return False
        
        # Check if process is running
        try:
            pid = int(self.pid_file.read_text().strip())
            os.kill(pid, 0)  # Check if process exists
            return True
        except (ValueError, OSError):
            return False
    
    def get_status(self) -> dict:
        """Get current status of the run."""
        status = {
            'active': self.is_active(),
            'metadata': None,
            'screenshot_count': 0,
            'latest_screenshot': None,
            'activity_detected': False
        }
        
        # Read metadata
        if self.metadata_file.exists():
            try:
                with open(self.metadata_file) as f:
                    status['metadata'] = json.load(f)
            except json.JSONDecodeError:
                pass
        
        # Count screenshots
        if self.screenshots_dir.exists():
            screenshots = list(self.screenshots_dir.glob("*.png"))
            status['screenshot_count'] = len(screenshots)
            
            if screenshots:
                latest = max(screenshots, key=lambda p: p.stat().st_mtime)
                status['latest_screenshot'] = latest.name
            
            # Detect activity
            if status['screenshot_count'] > self._last_screenshot_count:
                status['activity_detected'] = True
                self._last_screenshot_count = status['screenshot_count']
        
        # Check metadata modification
        if self.metadata_file.exists():
            mtime = self.metadata_file.stat().st_mtime
            if self._last_metadata_mtime and mtime > self._last_metadata_mtime:
                status['activity_detected'] = True
            self._last_metadata_mtime = mtime
        
        return status
    
    def wait_for_completion(
        self,
        poll_interval: int = 5,
        timeout: int = 3600,
        on_progress: Optional[Callable[[dict], None]] = None
    ) -> dict:
        """
        Block until run completes or times out.
        
        Args:
            poll_interval: Seconds between status checks
            timeout: Maximum seconds to wait
            on_progress: Optional callback called with status on each check
            
        Returns:
            Final status dict
        """
        start_time = time.time()
        
        while True:
            status = self.get_status()
            
            if on_progress:
                on_progress(status)
            
            if not status['active']:
                return status
            
            if time.time() - start_time > timeout:
                status['timeout'] = True
                return status
            
            time.sleep(poll_interval)


def watch_run_live(
    run_dir: str,
    poll_interval: int = 3,
    show_screenshots: bool = False
):
    """
    Watch a run in real-time with live console output.
    
    Args:
        run_dir: Path to run directory
        poll_interval: Seconds between updates
        show_screenshots: Whether to show screenshot filenames
    """
    watcher = ActivityWatcher(run_dir)
    run_id = Path(run_dir).name
    
    print(f"\n{'='*60}")
    print(f"WATCHING: {run_id}")
    print(f"{'='*60}\n")
    
    last_iteration = -1
    last_phase = ""
    
    try:
        while True:
            status = watcher.get_status()
            
            if not status['active']:
                print("\n[RUN COMPLETED]")
                if status['metadata']:
                    m = status['metadata']
                    print(f"  Status: {m.get('status', 'unknown')}")
                    print(f"  Iterations: {m.get('total_iterations', m.get('current_iteration', '?'))}")
                    print(f"  Output files: {len(m.get('output_files', []))}")
                break
            
            if status['metadata']:
                m = status['metadata']
                iteration = m.get('current_iteration', 0)
                phase = m.get('current_phase', 'unknown')
                max_iter = m.get('max_iterations', 100)
                
                # Only print on changes
                if iteration != last_iteration or phase != last_phase:
                    progress = (iteration / max_iter) * 100
                    bar_width = 30
                    filled = int(bar_width * progress / 100)
                    bar = '#' * filled + '-' * (bar_width - filled)
                    
                    timestamp = datetime.now().strftime("%H:%M:%S")
                    print(f"[{timestamp}] [{bar}] {iteration}/{max_iter} | Phase: {phase}")
                    
                    if show_screenshots and status['latest_screenshot']:
                        print(f"           Latest screenshot: {status['latest_screenshot']}")
                    
                    last_iteration = iteration
                    last_phase = phase
            
            time.sleep(poll_interval)
    
    except KeyboardInterrupt:
        print("\n[WATCH STOPPED]")
    
    return watcher.get_status()
