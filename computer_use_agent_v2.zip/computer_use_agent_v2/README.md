# Claude Computer Use Agent v2

Enhanced autonomous GUI automation system using Claude's Computer Use API. This version adds robust monitoring, timeout detection, process management, and graceful shutdown capabilities.

## Key Improvements Over v1

| Feature | v1 | v2 |
|---------|----|----|
| **PID Tracking** | None | Full process.pid management |
| **Real-time Monitoring** | Manual file polling | `status` and `watch` commands |
| **Timeout Detection** | None (runs forever) | Configurable screenshot/iteration/runtime timeouts |
| **Graceful Shutdown** | Kill process manually | Ctrl+C handler, `stop` command |
| **Partial Success** | Binary success/fail | Tracks phases, detects PDML-only exports |
| **Frozen UI Detection** | None | Screenshot hash comparison |
| **Progress Updates** | Only at start/end | Every 5 iterations |

## Installation

```bash
# 1. Navigate to agent directory
cd computer_use_agent_v2

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set Anthropic API key
set ANTHROPIC_API_KEY=sk-ant-...  # Windows
export ANTHROPIC_API_KEY=sk-ant-...  # Linux/Mac
```

## Quick Start

```bash
# Run the smoke test (Notepad automation)
python run.py run --task smoke_test

# Check status of all runs
python run.py status

# Watch a running task
python run.py watch <run_id>

# Stop a hung task
python run.py stop <run_id>
```

## CLI Reference

### `run` - Execute a Task

```bash
python run.py run --task <name> [options]

Options:
  --task, -t        Task name (required)
  --input, -i       Input file path
  --output-dir, -o  Output directory
  --prompt, -p      Direct prompt text
  --prompt-file, -f Path to prompt file
  --model           Model to use (default: claude-sonnet-4-5)
  --max-iter        Max iterations (default: 100)
  --screenshot-timeout  Seconds before screenshot timeout (default: 120)
  --iteration-timeout   Seconds before iteration timeout (default: 180)
  --max-runtime        Max runtime in seconds (default: 1800)
```

**Examples:**

```bash
# Smoke test
python run.py run --task smoke_test

# PDS export with custom iterations
python run.py run --task export_pds --input "Basic Tee_2D.PDS" --max-iter 150

# Using a prompt file with variable substitution
python run.py run --task export_pds \
  --prompt-file prompts/optitex_export_pds.txt \
  --input "Light Jacket_2D.PDS"
```

### `status` - Show Run Status

```bash
python run.py status [--limit N]

Options:
  --limit, -n  Number of recent runs to show (default: 10)
```

**Output:**
```
======================================================================
AGENT STATUS - 2026-01-30 18:45:32
======================================================================

ACTIVE RUNS (1)
----------------------------------------------------------------------
  20260130_184521_export_pds_Light_Jacket_2D
    Task: export_pds | Phase: dxf_export
    Progress: [##########----------] 52/100 (52%)
    Last activity: 15s ago

RECENT RUNS (3)
----------------------------------------------------------------------
  Status       Task            Iterations   Duration   Run ID
  ------------ --------------- ------------ ---------- ------------------------------
  OK           export_pds      72/100       10.8m      20260130_175916_export_pds_Basic
  FAILED       export_pds      100/100      12.3m      20260130_181100_export_pds_Light
  TIMEOUT      export_pds      77/150       15.0m      20260130_183000_export_pds_Light
```

### `watch` - Real-time Monitoring

```bash
python run.py watch <run_id> [--interval N] [--screenshots]

Options:
  --interval, -i   Poll interval in seconds (default: 3)
  --screenshots, -s Show screenshot filenames
```

**Output:**
```
============================================================
WATCHING: 20260130_184521_export_pds_Light_Jacket_2D
============================================================

[18:45:35] [##########----------] 52/100 | Phase: dxf_export
[18:45:38] [###########---------] 55/100 | Phase: dxf_export
[18:45:41] [############--------] 58/100 | Phase: dxf_export
^C
[WATCH STOPPED]
```

### `stop` - Terminate a Run

```bash
python run.py stop <run_id> [--force]

Options:
  --force, -f  Skip confirmation prompt
```

### `list` - List All Runs

```bash
python run.py list [--limit N]
```

### `cleanup` - Remove Orphaned PIDs

```bash
python run.py cleanup
```

Removes PID files from processes that are no longer running and updates their status to "failed".

## Configuration

### Timeout Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `screenshot_timeout` | 120s | Fail if no screenshot captured for this long |
| `iteration_timeout` | 180s | Fail if no iteration progress for this long |
| `max_runtime` | 1800s | Maximum total runtime (30 minutes) |

### Recommended Settings by Task Complexity

| Task Type | max_iter | screenshot_timeout | iteration_timeout |
|-----------|----------|-------------------|-------------------|
| Simple (Notepad test) | 30 | 60 | 90 |
| Medium (single export) | 100 | 120 | 180 |
| Complex (multi-step) | 150 | 180 | 240 |
| Very complex | 200 | 240 | 300 |

## Directory Structure

```
computer_use_agent_v2/
├── run.py              # CLI entry point
├── agent_loop.py       # Core agent loop with timeout integration
├── tools.py            # Screenshot/mouse/keyboard control
├── run_logger.py       # Logging with PID tracking
├── timeout_monitor.py  # Timeout detection system
├── requirements.txt    # Python dependencies
├── prompts/           # Task prompt templates
│   ├── optitex_export_pds.txt
│   └── optitex_export_mrk.txt
└── run_logs/          # Execution logs (created at runtime)
    └── <run_id>/
        ├── metadata.json    # Real-time status
        ├── process.pid      # PID file (while running)
        ├── actions.json     # Action history
        ├── RUN_REPORT.md    # Human-readable report
        └── screenshots/     # Captured screenshots
```

## Run Metadata Schema

The `metadata.json` file is updated every 5 iterations:

```json
{
  "run_id": "20260130_175916_export_pds_Basic_Tee_2D_PDS",
  "task": "export_pds",
  "input_file": "Basic Tee_2D.PDS",
  "started_at": "2026-01-30T17:59:16",
  "pid": 12345,
  
  "status": "running",
  "current_phase": "dxf_export",
  "current_iteration": 52,
  "max_iterations": 100,
  "last_activity": "2026-01-30T18:05:32",
  "last_screenshot": "052_180532_iter_52.png",
  
  "phases_completed": [
    {"phase": "opening_file", "iterations_used": 8, "success": true},
    {"phase": "pdml_export", "iterations_used": 18, "success": true}
  ],
  "output_files": ["Basic Tee_2D.PDML"],
  "errors": [],
  
  "model": "claude-sonnet-4-5",
  "timeout_minutes": 30
}
```

## Prompt Templates

Templates support variable substitution:
- `{{INPUT_FILE}}` - Replaced with `--input` value
- `{{OUTPUT_DIR}}` - Replaced with `--output-dir` value

## Error Handling

### Timeout Types

1. **Screenshot Timeout**: No new screenshot for N seconds
   - Indicates agent is stuck waiting for something
   - Check if application is frozen

2. **Iteration Timeout**: No iteration progress for N seconds
   - API calls may be failing
   - Check network/API key

3. **Max Runtime**: Total execution exceeded limit
   - Task may be too complex
   - Increase `--max-runtime` or split task

4. **Frozen UI**: N consecutive identical screenshots
   - Application or Windows is frozen
   - Manual intervention required

### Recovery Options

```bash
# Stop the hung run
python run.py stop <run_id>

# Clean up orphaned processes
python run.py cleanup

# Retry with longer timeouts
python run.py run --task export_pds --input "file.PDS" \
  --max-iter 200 --screenshot-timeout 240
```

## Troubleshooting

### "No active runs" but process is running

```bash
# Clean up orphaned PID files
python run.py cleanup
```

### Watch shows "RUN COMPLETED" immediately

The run finished before you started watching. Check:
```bash
python run.py status
# or
cat run_logs/<run_id>/RUN_REPORT.md
```

### Partial success (PDML created, DXF missing)

This indicates the DXF export phase failed. Check:
1. `run_logs/<run_id>/screenshots/` for the failure point
2. `run_logs/<run_id>/actions.json` for the action sequence
3. Manual DXF export to verify Optitex isn't hanging

### API rate limits

If you see API errors, add delays:
```python
config = AgentConfig(
    post_action_delay=1.0,  # Increase from 0.5
    api_retry_delay=10.0    # Increase from 5.0
)
```

## Integration with Existing v1 Agent

To migrate from v1:

1. Copy prompt files from old `prompts/` directory
2. Keep existing `run_logs/` - v2 is backwards compatible
3. Update any scripts that call `run.py` to use new argument format

The v2 agent can read v1 log files but writes in the enhanced format with additional fields.
