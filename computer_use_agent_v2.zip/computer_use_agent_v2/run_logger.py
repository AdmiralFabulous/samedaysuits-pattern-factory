"""
Enhanced Run Logger with PID tracking, real-time progress updates, and phase tracking.

Key improvements over v1:
- PID file creation for process management
- Real-time metadata updates (iteration count, current phase)
- Phase tracking (opening, pdml_export, dxf_export, verification)
- Partial success tracking
- Lock file for safe concurrent access
"""

import json
import os
import time
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field, asdict
from enum import Enum
import fcntl  # For file locking on Windows, use msvcrt instead


class Phase(Enum):
    """Execution phases for tracking partial progress."""
    INITIALIZING = "initializing"
    OPENING_FILE = "opening_file"
    PDML_EXPORT = "pdml_export"
    DXF_EXPORT = "dxf_export"
    PLT_EXPORT = "plt_export"  # For MRK files
    VERIFICATION = "verification"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


class Status(Enum):
    """Run status values."""
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL = "partial"  # Some exports succeeded, others failed
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


@dataclass
class PhaseResult:
    """Result of a single phase."""
    phase: str
    started_at: str
    completed_at: Optional[str] = None
    success: bool = False
    output_files: List[str] = field(default_factory=list)
    error: Optional[str] = None
    iterations_used: int = 0


@dataclass
class RunMetadata:
    """Complete run metadata with real-time tracking."""
    run_id: str
    task: str
    input_file: str
    started_at: str
    pid: int
    
    # Real-time tracking
    status: str = Status.RUNNING.value
    current_phase: str = Phase.INITIALIZING.value
    current_iteration: int = 0
    max_iterations: int = 100
    last_activity: str = ""
    last_screenshot: Optional[str] = None
    
    # Progress tracking
    phases_completed: List[Dict] = field(default_factory=list)
    output_files: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    
    # Completion data
    completed_at: Optional[str] = None
    total_iterations: int = 0
    total_screenshots: int = 0
    duration_seconds: float = 0.0
    
    # Configuration
    model: str = "claude-sonnet-4-5"
    timeout_minutes: int = 30
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class RunLogger:
    """
    Enhanced logger with real-time progress tracking and PID management.
    
    Usage:
        logger = RunLogger(base_dir="./run_logs")
        run_id = logger.start_run(task="export_pds", input_file="Basic Tee_2D.PDS")
        
        # During execution
        logger.update_iteration(15)
        logger.set_phase(Phase.PDML_EXPORT)
        logger.save_screenshot(screenshot_bytes, "after_save_dialog")
        logger.add_output_file("Basic Tee_2D.PDML")
        
        # On completion
        logger.complete_run(success=True)
    """
    
    def __init__(self, base_dir: str = "./run_logs"):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        
        self.run_id: Optional[str] = None
        self.run_dir: Optional[Path] = None
        self.metadata: Optional[RunMetadata] = None
        self._lock = threading.Lock()
        self._phase_start_time: Optional[float] = None
        self._phase_start_iteration: int = 0
    
    def start_run(
        self,
        task: str,
        input_file: str,
        max_iterations: int = 100,
        model: str = "claude-sonnet-4-5",
        timeout_minutes: int = 30
    ) -> str:
        """Initialize a new run with PID tracking."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_input = self._safe_filename(input_file)
        self.run_id = f"{timestamp}_{task}_{safe_input}"
        
        self.run_dir = self.base_dir / self.run_id
        self.run_dir.mkdir(parents=True, exist_ok=True)
        (self.run_dir / "screenshots").mkdir(exist_ok=True)
        
        # Create metadata
        self.metadata = RunMetadata(
            run_id=self.run_id,
            task=task,
            input_file=input_file,
            started_at=datetime.now().isoformat(),
            pid=os.getpid(),
            max_iterations=max_iterations,
            model=model,
            timeout_minutes=timeout_minutes,
            last_activity=datetime.now().isoformat()
        )
        
        # Write PID file for process management
        self._write_pid_file()
        
        # Save initial metadata
        self._save_metadata()
        
        # Start initializing phase
        self._phase_start_time = time.time()
        self._phase_start_iteration = 0
        
        return self.run_id
    
    def _write_pid_file(self):
        """Write PID to file for process management."""
        pid_file = self.run_dir / "process.pid"
        pid_file.write_text(str(os.getpid()))
    
    def _safe_filename(self, filename: str) -> str:
        """Convert filename to safe directory name."""
        # Remove extension and replace unsafe chars
        name = Path(filename).stem
        for char in r'<>:"/\|?* ':
            name = name.replace(char, '_')
        return name[:50]  # Limit length
    
    def _save_metadata(self):
        """Save metadata to JSON with file locking."""
        if not self.metadata or not self.run_dir:
            return
        
        with self._lock:
            metadata_file = self.run_dir / "metadata.json"
            temp_file = self.run_dir / "metadata.json.tmp"
            
            # Write to temp file first
            with open(temp_file, 'w') as f:
                json.dump(self.metadata.to_dict(), f, indent=2)
            
            # Atomic rename
            temp_file.replace(metadata_file)
    
    def update_iteration(self, iteration: int):
        """Update current iteration count (call every iteration)."""
        if not self.metadata:
            return
        
        self.metadata.current_iteration = iteration
        self.metadata.last_activity = datetime.now().isoformat()
        
        # Save metadata every 5 iterations for real-time monitoring
        if iteration % 5 == 0:
            self._save_metadata()
    
    def set_phase(self, phase: Phase, force_save: bool = True):
        """
        Transition to a new phase, recording the previous phase's results.
        """
        if not self.metadata:
            return
        
        now = datetime.now()
        
        # Complete previous phase if there was one
        if self._phase_start_time and self.metadata.current_phase != Phase.INITIALIZING.value:
            phase_result = PhaseResult(
                phase=self.metadata.current_phase,
                started_at=datetime.fromtimestamp(self._phase_start_time).isoformat(),
                completed_at=now.isoformat(),
                success=phase not in [Phase.FAILED, Phase.TIMEOUT, Phase.CANCELLED],
                iterations_used=self.metadata.current_iteration - self._phase_start_iteration
            )
            self.metadata.phases_completed.append(asdict(phase_result))
        
        # Start new phase
        self.metadata.current_phase = phase.value
        self.metadata.last_activity = now.isoformat()
        self._phase_start_time = time.time()
        self._phase_start_iteration = self.metadata.current_iteration
        
        if force_save:
            self._save_metadata()
    
    def save_screenshot(self, image_data: bytes, label: str = "") -> str:
        """Save a screenshot and update tracking."""
        if not self.run_dir or not self.metadata:
            return ""
        
        self.metadata.total_screenshots += 1
        timestamp = datetime.now().strftime("%H%M%S")
        iteration = self.metadata.current_iteration
        
        if label:
            filename = f"{iteration:03d}_{timestamp}_{label}.png"
        else:
            filename = f"{iteration:03d}_{timestamp}.png"
        
        filepath = self.run_dir / "screenshots" / filename
        filepath.write_bytes(image_data)
        
        self.metadata.last_screenshot = filename
        self.metadata.last_activity = datetime.now().isoformat()
        
        return str(filepath)
    
    def add_output_file(self, filepath: str):
        """Record an output file that was created."""
        if not self.metadata:
            return
        
        self.metadata.output_files.append(filepath)
        self.metadata.last_activity = datetime.now().isoformat()
        self._save_metadata()
    
    def add_error(self, error: str):
        """Record an error that occurred."""
        if not self.metadata:
            return
        
        timestamped_error = f"[{datetime.now().isoformat()}] {error}"
        self.metadata.errors.append(timestamped_error)
        self._save_metadata()
    
    def complete_run(self, success: bool, error: Optional[str] = None):
        """Mark run as completed and generate final report."""
        if not self.metadata:
            return
        
        now = datetime.now()
        start_time = datetime.fromisoformat(self.metadata.started_at)
        
        self.metadata.completed_at = now.isoformat()
        self.metadata.duration_seconds = (now - start_time).total_seconds()
        self.metadata.total_iterations = self.metadata.current_iteration
        
        # Determine final status
        if error:
            self.metadata.errors.append(f"[{now.isoformat()}] {error}")
        
        if success:
            self.metadata.status = Status.COMPLETED.value
            self.set_phase(Phase.COMPLETED, force_save=False)
        elif self.metadata.output_files:
            # Partial success - some files created
            self.metadata.status = Status.PARTIAL.value
            self.set_phase(Phase.FAILED, force_save=False)
        else:
            self.metadata.status = Status.FAILED.value
            self.set_phase(Phase.FAILED, force_save=False)
        
        self._save_metadata()
        self._generate_report()
        self._cleanup_pid_file()
    
    def timeout_run(self, reason: str = "No activity detected"):
        """Mark run as timed out."""
        if not self.metadata:
            return
        
        self.metadata.status = Status.TIMEOUT.value
        self.complete_run(success=False, error=f"TIMEOUT: {reason}")
    
    def cancel_run(self, reason: str = "User cancelled"):
        """Mark run as cancelled."""
        if not self.metadata:
            return
        
        self.metadata.status = Status.CANCELLED.value
        self.complete_run(success=False, error=f"CANCELLED: {reason}")
    
    def _cleanup_pid_file(self):
        """Remove PID file on completion."""
        if not self.run_dir:
            return
        
        pid_file = self.run_dir / "process.pid"
        if pid_file.exists():
            pid_file.unlink()
    
    def _generate_report(self):
        """Generate human-readable run report."""
        if not self.metadata or not self.run_dir:
            return
        
        report = self._build_report()
        report_file = self.run_dir / "RUN_REPORT.md"
        report_file.write_text(report)
    
    def _build_report(self) -> str:
        """Build markdown report content."""
        m = self.metadata
        
        # Status emoji
        status_emoji = {
            "completed": "SUCCESS",
            "partial": "PARTIAL",
            "failed": "FAILED",
            "timeout": "TIMEOUT",
            "cancelled": "CANCELLED"
        }.get(m.status, "UNKNOWN")
        
        report = f"""# Run Report: {m.run_id}

## Summary

| Field | Value |
|-------|-------|
| **Status** | {status_emoji} |
| **Task** | {m.task} |
| **Input File** | {m.input_file} |
| **Started** | {m.started_at} |
| **Completed** | {m.completed_at or 'N/A'} |
| **Duration** | {m.duration_seconds:.1f} seconds |
| **Iterations** | {m.total_iterations} / {m.max_iterations} |
| **Screenshots** | {m.total_screenshots} |
| **Model** | {m.model} |

## Output Files

"""
        if m.output_files:
            for f in m.output_files:
                report += f"- `{f}`\n"
        else:
            report += "_No output files created._\n"
        
        report += "\n## Phase History\n\n"
        
        if m.phases_completed:
            report += "| Phase | Duration | Iterations | Success |\n"
            report += "|-------|----------|------------|--------|\n"
            for phase in m.phases_completed:
                success = "Yes" if phase.get('success') else "No"
                report += f"| {phase['phase']} | - | {phase.get('iterations_used', 0)} | {success} |\n"
        else:
            report += "_No phases recorded._\n"
        
        if m.errors:
            report += "\n## Errors\n\n"
            for err in m.errors:
                report += f"- {err}\n"
        
        report += f"\n---\n_Generated: {datetime.now().isoformat()}_\n"
        
        return report
    
    def save_actions(self, actions: List[Dict]):
        """Save action history to JSON."""
        if not self.run_dir:
            return
        
        actions_file = self.run_dir / "actions.json"
        with open(actions_file, 'w') as f:
            json.dump(actions, f, indent=2)


def get_run_metadata(run_dir: Path) -> Optional[Dict]:
    """Read metadata from a run directory."""
    metadata_file = run_dir / "metadata.json"
    if metadata_file.exists():
        with open(metadata_file) as f:
            return json.load(f)
    return None


def get_active_runs(base_dir: str = "./run_logs") -> List[Dict]:
    """Get all currently active (running) runs."""
    base = Path(base_dir)
    active = []
    
    if not base.exists():
        return active
    
    for run_dir in base.iterdir():
        if not run_dir.is_dir():
            continue
        
        pid_file = run_dir / "process.pid"
        metadata_file = run_dir / "metadata.json"
        
        # Check if PID file exists (indicates running)
        if pid_file.exists() and metadata_file.exists():
            try:
                pid = int(pid_file.read_text().strip())
                metadata = json.loads(metadata_file.read_text())
                
                # Check if process is actually running
                if _is_process_running(pid):
                    metadata['run_dir'] = str(run_dir)
                    active.append(metadata)
            except (ValueError, json.JSONDecodeError):
                continue
    
    return active


def get_all_runs(base_dir: str = "./run_logs", limit: int = 20) -> List[Dict]:
    """Get all runs, sorted by most recent first."""
    base = Path(base_dir)
    runs = []
    
    if not base.exists():
        return runs
    
    for run_dir in sorted(base.iterdir(), reverse=True):
        if not run_dir.is_dir():
            continue
        
        metadata = get_run_metadata(run_dir)
        if metadata:
            metadata['run_dir'] = str(run_dir)
            runs.append(metadata)
        
        if len(runs) >= limit:
            break
    
    return runs


def _is_process_running(pid: int) -> bool:
    """Check if a process with given PID is running."""
    try:
        os.kill(pid, 0)  # Signal 0 doesn't kill, just checks
        return True
    except OSError:
        return False


def kill_run(run_id: str, base_dir: str = "./run_logs") -> bool:
    """Kill a running process by run_id."""
    import signal
    
    run_dir = Path(base_dir) / run_id
    pid_file = run_dir / "process.pid"
    
    if not pid_file.exists():
        return False
    
    try:
        pid = int(pid_file.read_text().strip())
        
        # On Windows, use taskkill; on Unix, use signals
        if os.name == 'nt':
            os.system(f'taskkill /F /PID {pid}')
        else:
            os.kill(pid, signal.SIGTERM)
        
        # Update metadata
        metadata_file = run_dir / "metadata.json"
        if metadata_file.exists():
            metadata = json.loads(metadata_file.read_text())
            metadata['status'] = Status.CANCELLED.value
            metadata['completed_at'] = datetime.now().isoformat()
            metadata['errors'] = metadata.get('errors', []) + [
                f"[{datetime.now().isoformat()}] Process killed by user"
            ]
            with open(metadata_file, 'w') as f:
                json.dump(metadata, f, indent=2)
        
        # Remove PID file
        pid_file.unlink()
        
        return True
    except (ValueError, OSError, PermissionError):
        return False
