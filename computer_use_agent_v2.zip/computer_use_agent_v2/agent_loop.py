"""
Enhanced Agent Loop for Claude Computer Use.

Features:
- Integrated timeout monitoring
- Graceful Ctrl+C handling with state preservation
- Real-time progress tracking via RunLogger
- Screenshot hashing for frozen UI detection
- Configurable retry and recovery logic
- Action history with full audit trail
"""

import os
import sys
import signal
import time
import json
from datetime import datetime
from typing import Optional, List, Dict, Any, Callable
from dataclasses import dataclass, field

# Anthropic SDK
from anthropic import Anthropic

# Local modules
from tools import (
    get_screen_info, 
    capture_screenshot, 
    execute_action,
    ScreenInfo
)
from run_logger import RunLogger, Phase, Status
from timeout_monitor import TimeoutMonitor


# Configuration defaults
DEFAULT_MODEL = "claude-sonnet-4-5"
DEFAULT_MAX_TOKENS = 4096
DEFAULT_MAX_ITERATIONS = 100
DEFAULT_SCREENSHOT_TIMEOUT = 120  # seconds
DEFAULT_ITERATION_TIMEOUT = 180   # seconds  
DEFAULT_MAX_RUNTIME = 1800        # 30 minutes

# Claude Computer Use beta version
COMPUTER_USE_BETA = "computer-use-2025-01-24"


@dataclass
class AgentConfig:
    """Configuration for agent execution."""
    model: str = DEFAULT_MODEL
    max_tokens: int = DEFAULT_MAX_TOKENS
    max_iterations: int = DEFAULT_MAX_ITERATIONS
    screenshot_timeout: int = DEFAULT_SCREENSHOT_TIMEOUT
    iteration_timeout: int = DEFAULT_ITERATION_TIMEOUT
    max_runtime: int = DEFAULT_MAX_RUNTIME
    
    # Action timing
    post_action_delay: float = 0.5  # seconds after each action
    post_click_delay: float = 0.3   # additional delay after clicks
    
    # Retry logic
    max_api_retries: int = 3
    api_retry_delay: float = 5.0
    
    # Screenshots
    save_all_screenshots: bool = True
    
    # Safety
    confirm_destructive: bool = False  # Pause before file operations
    
    def to_dict(self) -> Dict:
        return {
            'model': self.model,
            'max_tokens': self.max_tokens,
            'max_iterations': self.max_iterations,
            'screenshot_timeout': self.screenshot_timeout,
            'iteration_timeout': self.iteration_timeout,
            'max_runtime': self.max_runtime,
        }


@dataclass
class AgentState:
    """Runtime state tracking."""
    iteration: int = 0
    messages: List[Dict] = field(default_factory=list)
    actions: List[Dict] = field(default_factory=list)
    
    # Tracking
    screenshots_captured: int = 0
    last_screenshot_hash: str = ""
    consecutive_identical_screenshots: int = 0
    
    # Flags
    should_stop: bool = False
    stop_reason: str = ""
    task_completed: bool = False


class AgentLoop:
    """
    Main agent loop for Claude Computer Use.
    
    Usage:
        agent = AgentLoop(
            task_prompt="Open Notepad and type 'Hello World'",
            logger=logger,
            config=AgentConfig(max_iterations=50)
        )
        
        success = agent.run()
        
        # Or with context manager
        with AgentLoop(...) as agent:
            agent.run()
    """
    
    def __init__(
        self,
        task_prompt: str,
        logger: RunLogger,
        config: Optional[AgentConfig] = None,
        on_action: Optional[Callable[[Dict], None]] = None,
        on_screenshot: Optional[Callable[[bytes, str], None]] = None,
    ):
        self.task_prompt = task_prompt
        self.logger = logger
        self.config = config or AgentConfig()
        self.on_action = on_action
        self.on_screenshot = on_screenshot
        
        # Initialize state
        self.state = AgentState()
        self.screen_info: Optional[ScreenInfo] = None
        
        # Anthropic client
        self.client = Anthropic()
        
        # Timeout monitor
        self.timeout_monitor: Optional[TimeoutMonitor] = None
        
        # Signal handling
        self._original_sigint = None
        self._original_sigterm = None
    
    def __enter__(self):
        self._setup_signal_handlers()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self._restore_signal_handlers()
        if self.timeout_monitor:
            self.timeout_monitor.stop()
        return False
    
    def _setup_signal_handlers(self):
        """Install graceful shutdown handlers."""
        self._original_sigint = signal.signal(signal.SIGINT, self._handle_interrupt)
        if hasattr(signal, 'SIGTERM'):
            self._original_sigterm = signal.signal(signal.SIGTERM, self._handle_interrupt)
    
    def _restore_signal_handlers(self):
        """Restore original signal handlers."""
        if self._original_sigint:
            signal.signal(signal.SIGINT, self._original_sigint)
        if self._original_sigterm and hasattr(signal, 'SIGTERM'):
            signal.signal(signal.SIGTERM, self._original_sigterm)
    
    def _handle_interrupt(self, signum, frame):
        """Handle Ctrl+C gracefully."""
        print("\n[INTERRUPT] Graceful shutdown initiated...")
        self.state.should_stop = True
        self.state.stop_reason = "User interrupted (Ctrl+C)"
    
    def _handle_timeout(self, reason: str):
        """Handle timeout from monitor."""
        print(f"\n[TIMEOUT] {reason}")
        self.state.should_stop = True
        self.state.stop_reason = f"Timeout: {reason}"
    
    def run(self) -> bool:
        """
        Execute the agent loop.
        
        Returns:
            True if task completed successfully, False otherwise.
        """
        self._setup_signal_handlers()
        
        try:
            return self._run_loop()
        except Exception as e:
            self.logger.add_error(f"Unhandled exception: {str(e)}")
            self.logger.complete_run(success=False, error=str(e))
            raise
        finally:
            self._restore_signal_handlers()
            if self.timeout_monitor:
                self.timeout_monitor.stop()
    
    def _run_loop(self) -> bool:
        """Main execution loop."""
        
        # Initialize screen info
        self.screen_info = get_screen_info()
        print(f"[INIT] Screen: {self.screen_info.native_width}x{self.screen_info.native_height}")
        print(f"[INIT] Scaled: {self.screen_info.scaled_width}x{self.screen_info.scaled_height}")
        
        # Start timeout monitor
        self.timeout_monitor = TimeoutMonitor(
            on_timeout=self._handle_timeout,
            screenshot_timeout=self.config.screenshot_timeout,
            iteration_timeout=self.config.iteration_timeout,
            max_runtime=self.config.max_runtime
        )
        self.timeout_monitor.start()
        
        # Capture initial screenshot
        self.logger.set_phase(Phase.OPENING_FILE)
        screenshot_b64, screenshot_bytes, screenshot_hash = capture_screenshot(self.screen_info)
        self._save_screenshot(screenshot_bytes, "initial")
        self.timeout_monitor.record_screenshot(screenshot_hash)
        
        # Build initial messages
        self.state.messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": self.task_prompt
                    },
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/png",
                            "data": screenshot_b64
                        }
                    }
                ]
            }
        ]
        
        # Main loop
        while self.state.iteration < self.config.max_iterations:
            
            # Check for stop conditions
            if self.state.should_stop:
                print(f"[STOP] {self.state.stop_reason}")
                break
            
            if self.timeout_monitor.timed_out:
                print("[STOP] Timeout detected")
                break
            
            self.state.iteration += 1
            self.logger.update_iteration(self.state.iteration)
            self.timeout_monitor.record_iteration(self.state.iteration)
            
            print(f"[ITER {self.state.iteration}/{self.config.max_iterations}]", end=" ", flush=True)
            
            # Call Claude API
            response = self._call_api()
            if response is None:
                self.logger.add_error("API call failed after retries")
                break
            
            # Process response
            stop_reason = response.stop_reason
            
            # Check for end_turn (task complete)
            if stop_reason == "end_turn":
                # Extract text response
                for block in response.content:
                    if hasattr(block, 'text'):
                        print(f"Claude: {block.text[:100]}...")
                        
                        # Check for explicit completion indicators
                        text_lower = block.text.lower()
                        if any(phrase in text_lower for phrase in [
                            "task complete",
                            "successfully",
                            "finished",
                            "done",
                            "completed"
                        ]):
                            self.state.task_completed = True
                
                print("[COMPLETE] Claude finished")
                break
            
            # Process tool use
            if stop_reason == "tool_use":
                tool_results = self._process_tool_calls(response.content)
                
                # Add assistant response and tool results to messages
                self.state.messages.append({
                    "role": "assistant",
                    "content": response.content
                })
                self.state.messages.append({
                    "role": "user",
                    "content": tool_results
                })
            else:
                print(f"[UNEXPECTED] stop_reason={stop_reason}")
                break
            
            # Post-action delay
            time.sleep(self.config.post_action_delay)
        
        # Determine success
        success = self.state.task_completed and not self.timeout_monitor.timed_out
        
        # Determine final phase based on output files
        output_files = self.logger.metadata.output_files if self.logger.metadata else []
        if output_files:
            has_pdml = any('.pdml' in f.lower() or '.PDML' in f for f in output_files)
            has_dxf = any('.dxf' in f.lower() or '.DXF' in f for f in output_files)
            
            if has_pdml and has_dxf:
                self.logger.set_phase(Phase.VERIFICATION)
            elif has_pdml:
                self.logger.set_phase(Phase.DXF_EXPORT)  # Stuck at DXF phase
        
        # Save action history
        self.logger.save_actions(self.state.actions)
        
        # Complete the run
        if self.timeout_monitor.timed_out:
            self.logger.timeout_run(self.state.stop_reason)
        elif self.state.should_stop and "interrupt" in self.state.stop_reason.lower():
            self.logger.cancel_run(self.state.stop_reason)
        else:
            self.logger.complete_run(success=success)
        
        return success
    
    def _call_api(self) -> Optional[Any]:
        """Call Claude API with retry logic."""
        
        tools = [
            {
                "type": f"computer_{COMPUTER_USE_BETA.split('-')[-1].replace('-', '')}",
                "name": "computer",
                "display_width_px": self.screen_info.scaled_width,
                "display_height_px": self.screen_info.scaled_height,
            }
        ]
        
        for attempt in range(self.config.max_api_retries):
            try:
                response = self.client.beta.messages.create(
                    model=self.config.model,
                    max_tokens=self.config.max_tokens,
                    tools=tools,
                    messages=self.state.messages,
                    betas=[COMPUTER_USE_BETA]
                )
                return response
            
            except Exception as e:
                print(f"[API ERROR] Attempt {attempt + 1}: {str(e)}")
                if attempt < self.config.max_api_retries - 1:
                    time.sleep(self.config.api_retry_delay)
                else:
                    return None
        
        return None
    
    def _process_tool_calls(self, content: List) -> List[Dict]:
        """Process tool calls from Claude response."""
        
        tool_results = []
        
        for block in content:
            if block.type == "tool_use":
                tool_name = block.name
                tool_input = block.input
                tool_id = block.id
                
                # Record action
                action_record = {
                    "iteration": self.state.iteration,
                    "timestamp": datetime.now().isoformat(),
                    "tool": tool_name,
                    "input": tool_input,
                }
                
                print(f"{tool_input.get('action', 'unknown')}", end=" ", flush=True)
                
                # Execute action
                if tool_input.get('action') == 'screenshot':
                    # Capture new screenshot
                    screenshot_b64, screenshot_bytes, screenshot_hash = capture_screenshot(self.screen_info)
                    self._save_screenshot(screenshot_bytes, f"iter_{self.state.iteration}")
                    self.timeout_monitor.record_screenshot(screenshot_hash)
                    
                    # Track identical screenshots
                    if screenshot_hash == self.state.last_screenshot_hash:
                        self.state.consecutive_identical_screenshots += 1
                    else:
                        self.state.consecutive_identical_screenshots = 0
                    self.state.last_screenshot_hash = screenshot_hash
                    
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": tool_id,
                        "content": [
                            {
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": "image/png",
                                    "data": screenshot_b64
                                }
                            }
                        ]
                    })
                    action_record["result"] = "screenshot_captured"
                    
                else:
                    # Execute other action
                    result = execute_action(tool_input, self.screen_info)
                    
                    # Additional delay for clicks
                    if 'click' in tool_input.get('action', ''):
                        time.sleep(self.config.post_click_delay)
                    
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": tool_id,
                        "content": result
                    })
                    action_record["result"] = result
                
                self.state.actions.append(action_record)
                
                # Callback
                if self.on_action:
                    self.on_action(action_record)
            
            elif hasattr(block, 'text'):
                print(f"[TEXT] {block.text[:50]}...", end=" ", flush=True)
        
        print()  # Newline after iteration
        return tool_results
    
    def _save_screenshot(self, screenshot_bytes: bytes, label: str):
        """Save screenshot and update tracking."""
        self.state.screenshots_captured += 1
        
        if self.config.save_all_screenshots:
            filepath = self.logger.save_screenshot(screenshot_bytes, label)
            
            if self.on_screenshot:
                self.on_screenshot(screenshot_bytes, filepath)


def run_agent(
    task_prompt: str,
    task_name: str,
    input_file: str,
    log_dir: str = "./run_logs",
    config: Optional[AgentConfig] = None
) -> bool:
    """
    Convenience function to run an agent task.
    
    Args:
        task_prompt: The prompt/instructions for the agent
        task_name: Name of the task (e.g., "export_pds")
        input_file: Input file being processed
        log_dir: Directory for run logs
        config: Agent configuration
        
    Returns:
        True if successful, False otherwise
    """
    config = config or AgentConfig()
    
    logger = RunLogger(base_dir=log_dir)
    run_id = logger.start_run(
        task=task_name,
        input_file=input_file,
        max_iterations=config.max_iterations,
        model=config.model,
        timeout_minutes=config.max_runtime // 60
    )
    
    print(f"[START] Run ID: {run_id}")
    
    with AgentLoop(
        task_prompt=task_prompt,
        logger=logger,
        config=config
    ) as agent:
        success = agent.run()
    
    print(f"[END] Success: {success}")
    
    return success
