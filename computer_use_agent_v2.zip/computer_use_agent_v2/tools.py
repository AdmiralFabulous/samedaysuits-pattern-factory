"""
Enhanced Tools Module for Claude Computer Use.

Provides:
- Screenshot capture with scaling and hash computation
- Mouse control (click, double-click, drag)
- Keyboard control (type, key press, hotkeys)
- Coordinate scaling utilities

Designed for Windows but with cross-platform fallbacks.
"""

import base64
import hashlib
import io
import time
from dataclasses import dataclass
from typing import Tuple, Optional, List
import platform


# Lazy imports for Windows-specific modules
_mss = None
_PIL = None
_pyautogui = None


def _get_mss():
    global _mss
    if _mss is None:
        import mss
        _mss = mss.mss()
    return _mss


def _get_pil():
    global _PIL
    if _PIL is None:
        from PIL import Image
        _PIL = Image
    return _PIL


def _get_pyautogui():
    global _pyautogui
    if _pyautogui is None:
        import pyautogui
        pyautogui.FAILSAFE = True  # Move mouse to corner to abort
        pyautogui.PAUSE = 0.1      # Small pause between actions
        _pyautogui = pyautogui
    return _pyautogui


# Claude Computer Use API constraints
MAX_LONG_EDGE = 1568
MAX_PIXELS = 1_150_000  # ~1.15 megapixels


@dataclass
class ScreenInfo:
    """Information about the display and scaling."""
    native_width: int
    native_height: int
    scaled_width: int
    scaled_height: int
    scale_factor: float


def get_screen_info() -> ScreenInfo:
    """Get display dimensions and compute optimal scaling for Claude API."""
    mss = _get_mss()
    
    # Get primary monitor
    monitor = mss.monitors[1]  # 0 is "all monitors combined"
    native_w = monitor['width']
    native_h = monitor['height']
    
    # Compute scale to fit Claude's constraints
    scale = 1.0
    
    # Constraint 1: Long edge <= 1568
    long_edge = max(native_w, native_h)
    if long_edge > MAX_LONG_EDGE:
        scale = min(scale, MAX_LONG_EDGE / long_edge)
    
    # Constraint 2: Total pixels <= 1.15M
    total_pixels = native_w * native_h
    if total_pixels > MAX_PIXELS:
        scale = min(scale, (MAX_PIXELS / total_pixels) ** 0.5)
    
    scaled_w = int(native_w * scale)
    scaled_h = int(native_h * scale)
    
    return ScreenInfo(
        native_width=native_w,
        native_height=native_h,
        scaled_width=scaled_w,
        scaled_height=scaled_h,
        scale_factor=scale
    )


def capture_screenshot(
    screen_info: Optional[ScreenInfo] = None
) -> Tuple[str, bytes, str]:
    """
    Capture screenshot, scale it, and return as base64.
    
    Returns:
        Tuple of (base64_string, raw_png_bytes, content_hash)
    """
    if screen_info is None:
        screen_info = get_screen_info()
    
    mss = _get_mss()
    Image = _get_pil()
    
    # Capture
    monitor = mss.monitors[1]
    screenshot = mss.grab(monitor)
    
    # Convert to PIL Image
    img = Image.frombytes('RGB', screenshot.size, screenshot.bgra, 'raw', 'BGRX')
    
    # Scale down
    if screen_info.scale_factor < 1.0:
        img = img.resize(
            (screen_info.scaled_width, screen_info.scaled_height),
            Image.Resampling.LANCZOS
        )
    
    # Encode to PNG
    buffer = io.BytesIO()
    img.save(buffer, format='PNG', optimize=True)
    png_bytes = buffer.getvalue()
    
    # Compute hash for frozen UI detection
    content_hash = hashlib.md5(png_bytes).hexdigest()[:16]
    
    # Base64 encode
    b64_string = base64.standard_b64encode(png_bytes).decode('utf-8')
    
    return b64_string, png_bytes, content_hash


def scaled_to_native(
    x: int, 
    y: int, 
    screen_info: ScreenInfo
) -> Tuple[int, int]:
    """Convert scaled coordinates (from Claude) to native screen coordinates."""
    native_x = int(x / screen_info.scale_factor)
    native_y = int(y / screen_info.scale_factor)
    
    # Clamp to screen bounds
    native_x = max(0, min(native_x, screen_info.native_width - 1))
    native_y = max(0, min(native_y, screen_info.native_height - 1))
    
    return native_x, native_y


def click(
    x: int, 
    y: int, 
    screen_info: ScreenInfo,
    button: str = 'left',
    clicks: int = 1
):
    """
    Click at scaled coordinates.
    
    Args:
        x, y: Coordinates in scaled space (as returned by Claude)
        screen_info: Screen scaling info
        button: 'left', 'right', or 'middle'
        clicks: Number of clicks (1 for single, 2 for double)
    """
    pyautogui = _get_pyautogui()
    
    native_x, native_y = scaled_to_native(x, y, screen_info)
    pyautogui.click(native_x, native_y, button=button, clicks=clicks)


def double_click(x: int, y: int, screen_info: ScreenInfo):
    """Double-click at scaled coordinates."""
    click(x, y, screen_info, clicks=2)


def right_click(x: int, y: int, screen_info: ScreenInfo):
    """Right-click at scaled coordinates."""
    click(x, y, screen_info, button='right')


def move_to(x: int, y: int, screen_info: ScreenInfo, duration: float = 0.2):
    """Move mouse to scaled coordinates."""
    pyautogui = _get_pyautogui()
    
    native_x, native_y = scaled_to_native(x, y, screen_info)
    pyautogui.moveTo(native_x, native_y, duration=duration)


def drag_to(
    start_x: int, 
    start_y: int, 
    end_x: int, 
    end_y: int, 
    screen_info: ScreenInfo,
    duration: float = 0.5,
    button: str = 'left'
):
    """Drag from start to end coordinates."""
    pyautogui = _get_pyautogui()
    
    native_start = scaled_to_native(start_x, start_y, screen_info)
    native_end = scaled_to_native(end_x, end_y, screen_info)
    
    pyautogui.moveTo(native_start[0], native_start[1])
    pyautogui.drag(
        native_end[0] - native_start[0],
        native_end[1] - native_start[1],
        duration=duration,
        button=button
    )


def mouse_down(x: int, y: int, screen_info: ScreenInfo, button: str = 'left'):
    """Press and hold mouse button at coordinates."""
    pyautogui = _get_pyautogui()
    
    native_x, native_y = scaled_to_native(x, y, screen_info)
    pyautogui.moveTo(native_x, native_y)
    pyautogui.mouseDown(button=button)


def mouse_up(button: str = 'left'):
    """Release mouse button."""
    pyautogui = _get_pyautogui()
    pyautogui.mouseUp(button=button)


def scroll(
    x: int, 
    y: int, 
    screen_info: ScreenInfo,
    direction: str = 'down',
    amount: int = 3
):
    """
    Scroll at specified coordinates.
    
    Args:
        x, y: Coordinates in scaled space
        screen_info: Screen scaling info
        direction: 'up', 'down', 'left', 'right'
        amount: Number of scroll units
    """
    pyautogui = _get_pyautogui()
    
    native_x, native_y = scaled_to_native(x, y, screen_info)
    pyautogui.moveTo(native_x, native_y)
    
    if direction == 'up':
        pyautogui.scroll(amount)
    elif direction == 'down':
        pyautogui.scroll(-amount)
    elif direction == 'left':
        pyautogui.hscroll(-amount)
    elif direction == 'right':
        pyautogui.hscroll(amount)


def type_text(text: str, interval: float = 0.02):
    """
    Type text string.
    
    Args:
        text: Text to type
        interval: Delay between characters (seconds)
    """
    pyautogui = _get_pyautogui()
    pyautogui.write(text, interval=interval)


def press_key(key: str):
    """
    Press a single key.
    
    Args:
        key: Key name (e.g., 'enter', 'tab', 'escape', 'f1', etc.)
    """
    pyautogui = _get_pyautogui()
    pyautogui.press(key)


def hotkey(*keys: str):
    """
    Press a key combination (hotkey).
    
    Args:
        keys: Keys to press together (e.g., 'ctrl', 'c' for Ctrl+C)
    """
    pyautogui = _get_pyautogui()
    pyautogui.hotkey(*keys)


def key_down(key: str):
    """Hold down a key."""
    pyautogui = _get_pyautogui()
    pyautogui.keyDown(key)


def key_up(key: str):
    """Release a key."""
    pyautogui = _get_pyautogui()
    pyautogui.keyUp(key)


# Key name mappings for Claude's key format
KEY_MAPPINGS = {
    'Return': 'enter',
    'return': 'enter',
    'Enter': 'enter',
    'Escape': 'escape',
    'escape': 'esc',
    'BackSpace': 'backspace',
    'Tab': 'tab',
    'space': 'space',
    'Space': 'space',
    'Delete': 'delete',
    'Home': 'home',
    'End': 'end',
    'Page_Up': 'pageup',
    'Page_Down': 'pagedown',
    'Up': 'up',
    'Down': 'down',
    'Left': 'left',
    'Right': 'right',
    'F1': 'f1', 'F2': 'f2', 'F3': 'f3', 'F4': 'f4',
    'F5': 'f5', 'F6': 'f6', 'F7': 'f7', 'F8': 'f8',
    'F9': 'f9', 'F10': 'f10', 'F11': 'f11', 'F12': 'f12',
    'Control_L': 'ctrl', 'Control_R': 'ctrl',
    'Alt_L': 'alt', 'Alt_R': 'alt',
    'Shift_L': 'shift', 'Shift_R': 'shift',
    'Super_L': 'win', 'Super_R': 'win',
}


def normalize_key(key: str) -> str:
    """Convert Claude's key format to pyautogui format."""
    return KEY_MAPPINGS.get(key, key.lower())


def execute_action(action: dict, screen_info: ScreenInfo) -> str:
    """
    Execute a Claude computer use action.
    
    Args:
        action: Action dict from Claude API response
        screen_info: Screen scaling info
        
    Returns:
        Result string (usually "ok" or error message)
    """
    action_type = action.get('action')
    
    try:
        if action_type == 'screenshot':
            # Don't actually capture here - caller handles this
            return "screenshot_requested"
        
        elif action_type == 'left_click':
            coord = action.get('coordinate', [0, 0])
            click(coord[0], coord[1], screen_info, button='left')
            return "ok"
        
        elif action_type == 'right_click':
            coord = action.get('coordinate', [0, 0])
            right_click(coord[0], coord[1], screen_info)
            return "ok"
        
        elif action_type == 'double_click':
            coord = action.get('coordinate', [0, 0])
            double_click(coord[0], coord[1], screen_info)
            return "ok"
        
        elif action_type == 'triple_click':
            coord = action.get('coordinate', [0, 0])
            click(coord[0], coord[1], screen_info, clicks=3)
            return "ok"
        
        elif action_type == 'middle_click':
            coord = action.get('coordinate', [0, 0])
            click(coord[0], coord[1], screen_info, button='middle')
            return "ok"
        
        elif action_type == 'left_click_drag':
            start = action.get('startCoordinate', action.get('start_coordinate', [0, 0]))
            end = action.get('endCoordinate', action.get('end_coordinate', [0, 0]))
            drag_to(start[0], start[1], end[0], end[1], screen_info)
            return "ok"
        
        elif action_type == 'left_mouse_down':
            coord = action.get('coordinate', [0, 0])
            mouse_down(coord[0], coord[1], screen_info, button='left')
            return "ok"
        
        elif action_type == 'left_mouse_up':
            mouse_up(button='left')
            return "ok"
        
        elif action_type == 'scroll':
            coord = action.get('coordinate', [0, 0])
            direction = action.get('direction', 'down')
            amount = action.get('amount', 3)
            scroll(coord[0], coord[1], screen_info, direction, amount)
            return "ok"
        
        elif action_type == 'type':
            text = action.get('text', '')
            type_text(text)
            return "ok"
        
        elif action_type == 'key':
            key = action.get('key', '')
            # Handle modifier+key combinations
            if '+' in key:
                keys = [normalize_key(k.strip()) for k in key.split('+')]
                hotkey(*keys)
            else:
                press_key(normalize_key(key))
            return "ok"
        
        elif action_type == 'hold_key':
            key = normalize_key(action.get('key', ''))
            key_down(key)
            return "ok"
        
        elif action_type == 'release_key':
            key = normalize_key(action.get('key', ''))
            key_up(key)
            return "ok"
        
        elif action_type == 'move':
            coord = action.get('coordinate', [0, 0])
            move_to(coord[0], coord[1], screen_info)
            return "ok"
        
        elif action_type == 'wait':
            duration = action.get('duration', 1)
            time.sleep(duration)
            return "ok"
        
        else:
            return f"Unknown action type: {action_type}"
    
    except Exception as e:
        return f"Error executing {action_type}: {str(e)}"


def get_cursor_position(screen_info: ScreenInfo) -> Tuple[int, int]:
    """Get current cursor position in scaled coordinates."""
    pyautogui = _get_pyautogui()
    
    native_x, native_y = pyautogui.position()
    
    scaled_x = int(native_x * screen_info.scale_factor)
    scaled_y = int(native_y * screen_info.scale_factor)
    
    return scaled_x, scaled_y


# Self-test function
def test_tools():
    """Quick self-test of tools module."""
    print("Testing tools module...")
    
    # Test screen info
    screen_info = get_screen_info()
    print(f"Screen: {screen_info.native_width}x{screen_info.native_height}")
    print(f"Scaled: {screen_info.scaled_width}x{screen_info.scaled_height}")
    print(f"Scale factor: {screen_info.scale_factor:.3f}")
    
    # Test screenshot capture
    b64, png_bytes, hash_val = capture_screenshot(screen_info)
    print(f"Screenshot: {len(png_bytes)} bytes, hash={hash_val}")
    
    # Test coordinate conversion
    test_x, test_y = 500, 300
    native = scaled_to_native(test_x, test_y, screen_info)
    print(f"Coords: ({test_x}, {test_y}) scaled -> {native} native")
    
    print("Tools module OK")


if __name__ == '__main__':
    test_tools()
