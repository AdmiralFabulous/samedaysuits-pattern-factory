"""
Claude Computer Use Agent v2

Enhanced autonomous GUI automation with:
- Real-time monitoring
- Timeout detection
- PID tracking
- Graceful shutdown
"""

from .run_logger import RunLogger, Phase, Status, get_active_runs, get_all_runs, kill_run
from .timeout_monitor import TimeoutMonitor, ActivityWatcher, watch_run_live
from .agent_loop import AgentLoop, AgentConfig, run_agent
from .tools import (
    get_screen_info,
    capture_screenshot,
    execute_action,
    ScreenInfo
)

__version__ = "2.0.0"
__all__ = [
    # Logger
    "RunLogger",
    "Phase", 
    "Status",
    "get_active_runs",
    "get_all_runs",
    "kill_run",
    
    # Monitor
    "TimeoutMonitor",
    "ActivityWatcher",
    "watch_run_live",
    
    # Agent
    "AgentLoop",
    "AgentConfig",
    "run_agent",
    
    # Tools
    "get_screen_info",
    "capture_screenshot",
    "execute_action",
    "ScreenInfo",
]
