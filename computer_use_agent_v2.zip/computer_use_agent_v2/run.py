#!/usr/bin/env python3
"""
Enhanced CLI for Claude Computer Use Agent.

Commands:
    run         Execute an agent task
    status      Show status of all runs (active and recent)
    watch       Watch a running task in real-time
    stop        Stop a running task by run_id
    list        List all run logs
    cleanup     Remove completed/orphaned PID files

Examples:
    # Run a task
    python run.py run --task smoke_test
    python run.py run --task export_pds --input "Basic Tee_2D.PDS" --max-iter 100
    
    # Monitor runs
    python run.py status
    python run.py watch 20260130_175916_export_pds_Basic_Tee
    
    # Stop a hung run
    python run.py stop 20260130_175916_export_pds_Basic_Tee
"""

import argparse
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

# Add parent dir to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from run_logger import (
    RunLogger, 
    get_active_runs, 
    get_all_runs, 
    get_run_metadata,
    kill_run,
    Phase
)
from timeout_monitor import ActivityWatcher, watch_run_live
from agent_loop import AgentLoop, AgentConfig, run_agent


# Default paths
DEFAULT_LOG_DIR = "./run_logs"
DEFAULT_PROMPTS_DIR = "./prompts"


def cmd_run(args):
    """Execute an agent task."""
    
    # Load prompt from file or use direct prompt
    if args.prompt_file:
        prompt_path = Path(args.prompt_file)
        if not prompt_path.exists():
            # Check prompts directory
            prompt_path = Path(DEFAULT_PROMPTS_DIR) / args.prompt_file
        
        if not prompt_path.exists():
            print(f"Error: Prompt file not found: {args.prompt_file}")
            sys.exit(1)
        
        task_prompt = prompt_path.read_text()
        
        # Substitute variables in prompt
        if args.input:
            task_prompt = task_prompt.replace("{{INPUT_FILE}}", args.input)
            task_prompt = task_prompt.replace("{{input_file}}", args.input)
        if args.output_dir:
            task_prompt = task_prompt.replace("{{OUTPUT_DIR}}", args.output_dir)
            task_prompt = task_prompt.replace("{{output_dir}}", args.output_dir)
    
    elif args.prompt:
        task_prompt = args.prompt
    
    else:
        # Use built-in prompts for known tasks
        task_prompts = {
            "smoke_test": """
Open Notepad on this Windows computer, type "Hello from Claude Computer Use!", 
then close Notepad WITHOUT saving. Take a screenshot after each action.
This is just a test - do NOT save any files.
""",
        }
        
        if args.task in task_prompts:
            task_prompt = task_prompts[args.task]
        else:
            print(f"Error: No prompt provided and no built-in prompt for task '{args.task}'")
            print(f"Built-in tasks: {list(task_prompts.keys())}")
            sys.exit(1)
    
    # Build config
    config = AgentConfig(
        model=args.model,
        max_iterations=args.max_iter,
        screenshot_timeout=args.screenshot_timeout,
        iteration_timeout=args.iteration_timeout,
        max_runtime=args.max_runtime,
    )
    
    # Run agent
    input_file = args.input or args.task
    
    print(f"\n{'='*60}")
    print(f"TASK: {args.task}")
    print(f"INPUT: {input_file}")
    print(f"MAX ITERATIONS: {config.max_iterations}")
    print(f"MODEL: {config.model}")
    print(f"{'='*60}\n")
    
    success = run_agent(
        task_prompt=task_prompt,
        task_name=args.task,
        input_file=input_file,
        log_dir=args.log_dir,
        config=config
    )
    
    sys.exit(0 if success else 1)


def cmd_status(args):
    """Show status of all runs."""
    
    print(f"\n{'='*70}")
    print(f"AGENT STATUS - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*70}\n")
    
    # Active runs
    active = get_active_runs(args.log_dir)
    
    print(f"ACTIVE RUNS ({len(active)})")
    print("-" * 70)
    
    if active:
        for run in active:
            run_id = run.get('run_id', 'unknown')
            task = run.get('task', 'unknown')
            phase = run.get('current_phase', 'unknown')
            iteration = run.get('current_iteration', 0)
            max_iter = run.get('max_iterations', 100)
            last_activity = run.get('last_activity', '')
            
            # Calculate time since last activity
            try:
                last_dt = datetime.fromisoformat(last_activity)
                age = (datetime.now() - last_dt).total_seconds()
                age_str = f"{age:.0f}s ago"
            except:
                age_str = "unknown"
            
            progress = (iteration / max_iter) * 100
            bar_width = 20
            filled = int(bar_width * progress / 100)
            bar = '#' * filled + '-' * (bar_width - filled)
            
            print(f"  {run_id[:40]}")
            print(f"    Task: {task} | Phase: {phase}")
            print(f"    Progress: [{bar}] {iteration}/{max_iter} ({progress:.0f}%)")
            print(f"    Last activity: {age_str}")
            print()
    else:
        print("  No active runs\n")
    
    # Recent completed runs
    all_runs = get_all_runs(args.log_dir, limit=args.limit)
    completed = [r for r in all_runs if r.get('status') != 'running' or r not in active]
    
    print(f"RECENT RUNS ({len(completed[:args.limit])})")
    print("-" * 70)
    
    if completed:
        # Table header
        print(f"  {'Status':<12} {'Task':<15} {'Iterations':<12} {'Duration':<10} {'Run ID'}")
        print(f"  {'-'*12} {'-'*15} {'-'*12} {'-'*10} {'-'*30}")
        
        for run in completed[:args.limit]:
            status = run.get('status', 'unknown')
            task = run.get('task', 'unknown')[:14]
            total_iter = run.get('total_iterations', run.get('current_iteration', 0))
            max_iter = run.get('max_iterations', 100)
            duration = run.get('duration_seconds', 0)
            run_id = run.get('run_id', 'unknown')[:30]
            
            # Status indicator
            status_map = {
                'completed': 'OK',
                'partial': 'PARTIAL',
                'failed': 'FAILED',
                'timeout': 'TIMEOUT',
                'cancelled': 'CANCEL',
                'running': 'RUNNING'
            }
            status_str = status_map.get(status, status.upper())
            
            # Duration formatting
            if duration > 60:
                dur_str = f"{duration/60:.1f}m"
            else:
                dur_str = f"{duration:.0f}s"
            
            print(f"  {status_str:<12} {task:<15} {total_iter:>4}/{max_iter:<6} {dur_str:<10} {run_id}")
    else:
        print("  No completed runs\n")
    
    print()


def cmd_watch(args):
    """Watch a running task in real-time."""
    
    run_dir = Path(args.log_dir) / args.run_id
    
    if not run_dir.exists():
        # Try partial match
        matches = list(Path(args.log_dir).glob(f"*{args.run_id}*"))
        if len(matches) == 1:
            run_dir = matches[0]
        elif len(matches) > 1:
            print(f"Multiple matches for '{args.run_id}':")
            for m in matches:
                print(f"  {m.name}")
            sys.exit(1)
        else:
            print(f"Error: Run not found: {args.run_id}")
            sys.exit(1)
    
    print(f"Watching: {run_dir.name}")
    watch_run_live(
        str(run_dir),
        poll_interval=args.interval,
        show_screenshots=args.screenshots
    )


def cmd_stop(args):
    """Stop a running task."""
    
    run_id = args.run_id
    
    # Try partial match if needed
    if not (Path(args.log_dir) / run_id).exists():
        matches = list(Path(args.log_dir).glob(f"*{run_id}*"))
        if len(matches) == 1:
            run_id = matches[0].name
        elif len(matches) > 1:
            print(f"Multiple matches for '{args.run_id}':")
            for m in matches:
                print(f"  {m.name}")
            sys.exit(1)
        else:
            print(f"Error: Run not found: {args.run_id}")
            sys.exit(1)
    
    print(f"Stopping run: {run_id}")
    
    if args.force or input("Confirm stop? [y/N] ").lower() == 'y':
        success = kill_run(run_id, args.log_dir)
        if success:
            print("Run stopped successfully")
        else:
            print("Failed to stop run (may already be stopped)")
    else:
        print("Cancelled")


def cmd_list(args):
    """List all run logs."""
    
    log_dir = Path(args.log_dir)
    
    if not log_dir.exists():
        print(f"Log directory does not exist: {log_dir}")
        sys.exit(1)
    
    runs = sorted(log_dir.iterdir(), reverse=True)
    
    print(f"\nRun logs in {log_dir}:")
    print("-" * 60)
    
    for run_dir in runs[:args.limit]:
        if not run_dir.is_dir():
            continue
        
        metadata = get_run_metadata(run_dir)
        if metadata:
            status = metadata.get('status', 'unknown')
            task = metadata.get('task', 'unknown')
            started = metadata.get('started_at', '')[:19]  # Trim to datetime
            
            # Check if running
            pid_file = run_dir / "process.pid"
            if pid_file.exists():
                status = "RUNNING"
            
            print(f"  {run_dir.name}")
            print(f"    {task} | {status} | {started}")
        else:
            print(f"  {run_dir.name} (no metadata)")
        
        print()


def cmd_cleanup(args):
    """Remove orphaned PID files from completed runs."""
    
    log_dir = Path(args.log_dir)
    cleaned = 0
    
    for run_dir in log_dir.iterdir():
        if not run_dir.is_dir():
            continue
        
        pid_file = run_dir / "process.pid"
        if pid_file.exists():
            try:
                pid = int(pid_file.read_text().strip())
                # Check if process is running
                try:
                    os.kill(pid, 0)
                    # Process is running, leave it alone
                except OSError:
                    # Process not running, remove orphaned PID file
                    pid_file.unlink()
                    cleaned += 1
                    print(f"Cleaned: {run_dir.name}")
                    
                    # Update metadata
                    metadata_file = run_dir / "metadata.json"
                    if metadata_file.exists():
                        metadata = json.loads(metadata_file.read_text())
                        if metadata.get('status') == 'running':
                            metadata['status'] = 'failed'
                            metadata['errors'] = metadata.get('errors', []) + [
                                f"[{datetime.now().isoformat()}] Orphaned process detected and cleaned"
                            ]
                            with open(metadata_file, 'w') as f:
                                json.dump(metadata, f, indent=2)
            except (ValueError, PermissionError):
                pass
    
    print(f"\nCleaned {cleaned} orphaned runs")


def main():
    parser = argparse.ArgumentParser(
        description="Claude Computer Use Agent CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    parser.add_argument(
        "--log-dir", 
        default=DEFAULT_LOG_DIR,
        help=f"Directory for run logs (default: {DEFAULT_LOG_DIR})"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Execute an agent task")
    run_parser.add_argument("--task", "-t", required=True, help="Task name")
    run_parser.add_argument("--input", "-i", help="Input file path")
    run_parser.add_argument("--output-dir", "-o", help="Output directory")
    run_parser.add_argument("--prompt", "-p", help="Direct prompt text")
    run_parser.add_argument("--prompt-file", "-f", help="Prompt file path")
    run_parser.add_argument("--model", default="claude-sonnet-4-5", help="Model to use")
    run_parser.add_argument("--max-iter", type=int, default=100, help="Max iterations")
    run_parser.add_argument("--screenshot-timeout", type=int, default=120, 
                           help="Seconds before screenshot timeout")
    run_parser.add_argument("--iteration-timeout", type=int, default=180,
                           help="Seconds before iteration timeout")
    run_parser.add_argument("--max-runtime", type=int, default=1800,
                           help="Max runtime in seconds")
    run_parser.set_defaults(func=cmd_run)
    
    # Status command
    status_parser = subparsers.add_parser("status", help="Show status of all runs")
    status_parser.add_argument("--limit", "-n", type=int, default=10, 
                               help="Number of recent runs to show")
    status_parser.set_defaults(func=cmd_status)
    
    # Watch command
    watch_parser = subparsers.add_parser("watch", help="Watch a running task")
    watch_parser.add_argument("run_id", help="Run ID to watch (partial match supported)")
    watch_parser.add_argument("--interval", "-i", type=int, default=3,
                              help="Poll interval in seconds")
    watch_parser.add_argument("--screenshots", "-s", action="store_true",
                              help="Show screenshot filenames")
    watch_parser.set_defaults(func=cmd_watch)
    
    # Stop command
    stop_parser = subparsers.add_parser("stop", help="Stop a running task")
    stop_parser.add_argument("run_id", help="Run ID to stop (partial match supported)")
    stop_parser.add_argument("--force", "-f", action="store_true",
                             help="Skip confirmation")
    stop_parser.set_defaults(func=cmd_stop)
    
    # List command
    list_parser = subparsers.add_parser("list", help="List all run logs")
    list_parser.add_argument("--limit", "-n", type=int, default=20,
                             help="Number of runs to show")
    list_parser.set_defaults(func=cmd_list)
    
    # Cleanup command
    cleanup_parser = subparsers.add_parser("cleanup", help="Remove orphaned PID files")
    cleanup_parser.set_defaults(func=cmd_cleanup)
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        sys.exit(1)
    
    args.func(args)


if __name__ == "__main__":
    main()
